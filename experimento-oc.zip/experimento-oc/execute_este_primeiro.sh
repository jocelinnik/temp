#!/bin/bash

echo "executando..."

sudo apt-get update
sudo apt-get install sysbench perf -y

echo "pronto"