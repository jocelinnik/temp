#!/bin/bash

echo "executando..."

gcc -o0 cache_not_friendly.c -o cache_not_friendly
for param in $(seq 10 10 1000);
do
    for i in $(seq 1 10);
    do
        perf stat -o saidas/saida_$param.txt --append -e cache-references,cache-misses ./cache_not_friendly $param > /dev/null 2>&1 
    done
done

echo "pronto"