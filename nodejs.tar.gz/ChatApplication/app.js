const express = require("express");
const moduloHttp = require("http");
const io = require("socket.io");
const bodyParser = require("body-parser");

const Chat = require("./models/Chat");
const connect = require("./dbconnection");
const chatRouter = require("./route/chatroute");

const app = express();
const http = moduloHttp.Server(app);
const port = 5000;
const socket = io(http);

app.use(express.static(__dirname + "/public"));
app.use(bodyParser.json());

app.use("/chats", chatRouter);

socket.on("connection", socket => {
    console.log("User connected");

    socket.on("disconnect", () => {
        console.log("User disconnected");
    });

    socket.on("chat message", msg => {
        console.log(`message: ${msg}`);

        socket.broadcast.emit("received", {message: msg});

        connect.then(db => {
            console.log("connected correctly to the server");

            let chatMessage = new Chat({
                message: msg,
                sender: "Anonymous"
            });
            chatMessage.save();
        });
    });
});

http.listen(port, () => {
    console.log(`connected to port ${port}`);
});
