let socket = io();
let messages = document.getElementById("messages");

(function(){
    $("form").submit(function(e){
        e.preventDefault();

        let li = document.createElement("li");
        let span = document.createElement("span");
        socket.emit("chat message", $("#message").val());

        messages.appendChild(li).append($("#message").val());
        messages.appendChild(span).append("by Anonymous: just now");
        $("#message").val("");

        return false;
    });

    socket.on("received", function(data){
        let li = document.createElement("li");
        let span = document.createElement("span");

        messages.appendChild(li).append($("#message").val());
        messages.appendChild(span).append("by Anonymous: just now");
    });
})();

(function(){
    fetch("/chats").then(function(data){
        return data.json();
    }).then(function(json){
        json.map(function(data){
            let li = document.createElement("li");
            let span = document.createElement("span");

            messages.appendChild(li).append(data.message);
            messages.appendChild(span).append(`by ${data.sender}: ${formatTimeAgo(data.createdAt)}`);
        });
    });
})();
